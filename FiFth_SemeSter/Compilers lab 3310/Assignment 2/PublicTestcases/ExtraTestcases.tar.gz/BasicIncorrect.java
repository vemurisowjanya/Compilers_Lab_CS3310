class BasicIncorrect{
    public static void main(String[] args){
        System.out.println(new A().work(24,new B()));
    }
}
class N {
    public boolean work(int[] a, Q var){
    
        if((2*true)||(3+(true-false)))
            if(((a.length)+false)&&(24*18))
                a[2]=false;
        return 0;
    }
}
class Z extends N{}
class A extends Z{}
class Q extends B{}
class B{
    int z;
}
